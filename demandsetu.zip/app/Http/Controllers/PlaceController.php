<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Destination;
use App\Models\Place;
use Illuminate\Support\Str;

class PlaceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $places = Place::where('status', 'active') // Filter by active status
            ->orderBy('created_at', 'desc')
            ->paginate(10);
        return view('admin.placelist', compact('places'));
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $destinations = Destination::all(); // Get all destinations from the database
        return view('admin.addplace', compact('destinations'));
    }
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'destination_id' => 'required|exists:destinations,id', // Validate the destination_id
            'title' => 'required|string|max:255|unique:places,title',
            'about' => 'required|string|max:500',
            'images' => 'required|array',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif,svg',
            'offers' => 'required|string|max:255',
            'duration' => 'required|string|max:100',
            'price' => 'required|numeric',
            'sale_price' => 'required|numeric',
            'description' => 'required|string',
            'country_status' => 'required|in:active,inactive', // Validate the status
        ]);

        // Handle image upload
        $imagePaths = [];
        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $image) {
                $filename = time() . '_' . $image->getClientOriginalName();
                $image->move(public_path('place_images'), $filename); // Store images in the 'place_images' directory
                $imagePaths[] = 'place_images/' . $filename;
            }
        }

        // Retrieve the selected destination name
        $destination = Destination::find($request->destination_id);
        $destinationName = $destination ? $destination->name : 'default';  // Default fallback if destination is not found

        // Generate the slug based on the destination name and the title
        $slugBase = Str::slug($destinationName . ' ' . $request->title); // Combining destination name with title
        $slug = $slugBase;

        // Ensure the slug is unique
        $count = 1;
        while (Place::where('slug', $slug)->exists()) {
            $slug = $slugBase . '-' . $count;
            $count++;
        }

        // Store the place data in the database
        $place = Place::create([
            'destination_id' => $request->destination_id,
            'title' => $request->title,
            'about' => $request->about,
            'images' => json_encode($imagePaths), // Save the array of image paths as a JSON string
            'offers' => $request->offers,
            'duration' => $request->duration,
            'price' => $request->price,
            'sale_price' => $request->sale_price,
            'description' => $request->description,
            'status' => $request->country_status,
            'slug' => $slug, // Save the generated slug
        ]);

        // Redirect to the places list page with a success message
        return redirect()->route('places.index')->with('success', 'Place added successfully!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $places = Place::findOrFail($id);
        $destinations = Destination::all();
        return view('admin.editplace', compact('places', 'destinations'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        // Validate the incoming request
        $request->validate([
            'destination_id' => 'required|exists:destinations,id', // Validate the destination_id
            'title' => 'required|string|max:255', // Ensure title is unique but allow updating the current one
            'about' => 'required|string|max:500',
            'images' => 'nullable|array', // Make images optional for updating
            'images.*' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg', // Allow image updates
            'offers' => 'required|string|max:255',
            'duration' => 'required|string|max:100',
            'price' => 'required|numeric',
            'sale_price' => 'required|numeric',
            'description' => 'required|string',
            // 'country_status' => 'required|in:active,inactive', // Validate the status
        ]);

        // Find the existing place by ID
        $place = Place::findOrFail($id);

        // Handle image upload if new images are provided
        $imagePaths = json_decode($place->images, true) ?? []; // Existing images in case no new ones are uploaded
        if ($request->hasFile('images')) {
            // If there are new images, handle image upload
            foreach ($request->file('images') as $image) {
                $filename = time() . '_' . $image->getClientOriginalName();
                $image->move(public_path('place_images'), $filename); // Store images in the 'place_images' directory
                $imagePaths[] = 'place_images/' . $filename;
            }
        }

        // Retrieve the selected destination name
        $destination = Destination::find($request->destination_id);
        $destinationName = $destination ? $destination->name : 'default';  // Default fallback if destination is not found

        // Generate the slug based on the destination name and the title
        $slugBase = Str::slug($destinationName . ' ' . $request->title); // Combining destination name with title
        $slug = $slugBase;

        // Ensure the slug is unique
        $count = 1;
        while (Place::where('slug', $slug)->where('id', '!=', $id)->exists()) { // Ensure it's unique but allow updating the current place
            $slug = $slugBase . '-' . $count;
            $count++;
        }

        // Update the place data in the database
        $place->update([
            'destination_id' => $request->destination_id,
            'title' => $request->title,
            'about' => $request->about,
            'images' => json_encode($imagePaths), // Save the updated array of image paths as a JSON string
            'offers' => $request->offers,
            'duration' => $request->duration,
            'price' => $request->price,
            'sale_price' => $request->sale_price,
            'description' => $request->description,
            'status' => $request->country_status,
            'slug' => $slug, // Save the generated slug
        ]);

        // Redirect to the places list page with a success message
        return redirect()->route('places.index')->with('success', 'Place updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $places = Place::findOrFail($id);
        $places->delete();
        return redirect()->route('places.index')->with('success', 'Place deleted successfully!');
    }
}
