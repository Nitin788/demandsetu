<?php

namespace App\Http\Controllers;

use App\Models\Homepage;
use Illuminate\Http\Request;

class HomepageController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Fetch homepages and decode the JSON fields
        $homepages = Homepage::orderBy('id', 'desc')->paginate(10);

        // Decode the JSON fields to arrays
        foreach ($homepages as $homepage) {
            $homepage->slider_images = json_decode($homepage->banner_image_title, true);
            $homepage->offer_image = json_decode($homepage->offer_image, true);
            $homepage->offer_card = json_decode($homepage->offer_card, true);
        }

        return view('admin.homepagelist', compact('homepages'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.addhomepagedata');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // dd($request->all());
        // Validate the form data
        $request->validate([
            'slider_images.*' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
            'titles.*' => 'required|string|max:255',
            'session_banners.*' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
            'card_titles.*' => 'required|string|max:255',
            'card_images.*' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
            'card_destinations.*' => 'required|string|max:255',
        ]);

        // Process Slider Images and Titles
        $sliderData = [];
        if ($request->hasFile('slider_images') && $request->has('titles')) {
            foreach ($request->file('slider_images') as $key => $image) {
                $filename = uniqid() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path('slider_images/'), $filename);
                // Store both the image path and its associated title
                $sliderData[] = [
                    'image' => 'slider_images/' . $filename,
                    'title' => $request->titles[$key],
                ];
            }
        }

        // Process Session Banners
        $sessionBanners = [];
        if ($request->hasFile('session_banners')) {
            foreach ($request->file('session_banners') as $banner) {
                $filename = uniqid() . '.' . $banner->getClientOriginalExtension();
                $banner->move(public_path('session_banners/'), $filename);
                $sessionBanners[] = 'session_banners/' . $filename;
            }
        }

        // Process Card Titles, Images, and Destinations
        $cardData = [];
        if ($request->has('card_titles') && $request->has('card_images') && $request->has('card_destinations')) {
            foreach ($request->card_titles as $key => $title) {
                $image = $request->file('card_images')[$key];
                $filename = uniqid() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path('card_images/'), $filename);
                $cardData[] = [
                    'title' => $title,
                    'image' => 'card_images/' . $filename,
                    'destination' => $request->card_destinations[$key],
                ];
            }
        }

        // Save the data into the database (assuming you have a model called Homepage)
        Homepage::create([
            'banner_image_title' => json_encode($sliderData), // You will need to add this field in your form
            'offer_image' => json_encode($sessionBanners),  // Store slider images as JSON
            'offer_card' => json_encode($cardData),  // Store card details as JSON
        ]);

        // Redirect or send response
        return redirect()->route('homepages.index')->with('success', 'Home Page Data added successfully!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Homepage $homepages)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $homepages = Homepage::findOrFail($id);
        return view('admin.edithomepage', compact('homepages'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        // Validate the form data
        $request->validate([
            'slider_images.*' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg',
            'titles.*' => 'required|string|max:255',
            'session_banners.*' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg',
            'card_titles.*' => 'required|string|max:255',
            'card_images.*' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg',
            'card_destinations.*' => 'required|string|max:255',
        ]);

        // Find the homepage record by ID
        $homepages = Homepage::findOrFail($id);

        // Process Slider Images
        $sliderImages = json_decode($homepages->slider_images, true) ?: [];
        if ($request->hasFile('slider_images')) {
            // Handle newly uploaded slider images
            foreach ($request->file('slider_images') as $image) {
                $filename = uniqid() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path('slider_images'), $filename);
                $sliderImages[] = 'slider_images/' . $filename;
            }
        }

        // Process Session Banners
        $sessionBanners = json_decode($homepages->session_banners, true) ?: [];
        if ($request->hasFile('session_banners')) {
            // Handle newly uploaded session banners
            foreach ($request->file('session_banners') as $banner) {
                $filename = uniqid() . '.' . $banner->getClientOriginalExtension();
                $banner->move(public_path('session_banners'), $filename);
                $sessionBanners[] = 'session_banners/' . $filename;
            }
        }

        // Process Card Titles, Images, and Destinations
        $cardData = json_decode($homepages->cards, true) ?: [];
        if ($request->has('card_titles') && $request->has('card_images') && $request->has('card_destinations')) {
            foreach ($request->card_titles as $key => $title) {
                // If a new image is uploaded for this card, process it
                if ($request->hasFile('card_images') && isset($request->file('card_images')[$key])) {
                    $image = $request->file('card_images')[$key];
                    $filename = uniqid() . '.' . $image->getClientOriginalExtension();
                    $image->move(public_path('card_images'), $filename);
                    // Update card image if a new one is uploaded
                    $cardData[$key]['image'] = 'card_images/' . $filename;
                }

                // Update the card title and destination
                $cardData[$key]['title'] = $title;
                $cardData[$key]['destination'] = $request->card_destinations[$key];
            }
        }

        // Update the homepage record in the database
        $homepages->update([
            'slider_images' => json_encode($sliderImages), // Store as JSON for multiple images
            'slider_titles' => json_encode($request->titles),
            'session_banners' => json_encode($sessionBanners),
            'cards' => json_encode($cardData),
        ]);

        // Redirect or send response
        return redirect()->route('homepages.index')->with('success', 'Offer has been updated successfully!');
    }



    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Homepage $homepages, $id)
    {
        $homepages = Homepage::findOrFail($id);
        $homepages->delete();
        return redirect()->route('homepages.index')->with('success', 'Home Page Data has been deleted successfully!');
    }
}
