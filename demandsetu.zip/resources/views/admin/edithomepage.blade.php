@extends('admin.app')

@section('content')
<div class="page-heading">
    <h1 class="page-title">Edit Home Page</h1>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="">Edit Home Page</a>
        </li>
        <li class="breadcrumb-item" style="margin-left: 30px;">
            <a href="{{ route('homepages.index') }}">Home Page List</a>
        </li>
    </ol>
</div>

<div class="page-content fade-in-up">
    <div class="row">
        <div class="col-md-12">
            <div class="ibox">
                <div class="ibox-head">
                    <div class="ibox-title">Edit Home Page Form</div>
                    <div class="ibox-tools">
                        <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                        <a class="fullscreen-link"><i class="fa fa-expand"></i></a>
                    </div>
                </div>
                <div class="ibox-body">
                    <form class="form-horizontal" action="{{ route('homepages.update', $homepage->id) }}" method="POST"
                        enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <!-- Display All Errors (if any) -->
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif

                        <!-- Slider Section -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="font-weight-bold">Slider Section</h5>
                            </div>
                            <div class="card-body">
                                <div id="slider-container">
                                    <!-- Loop through existing slider images and titles -->
                                    @foreach(json_decode($homepage->slider_images) as $index => $sliderImage)
                                        <div class="form-group row slider-group">
                                            <label class="col-sm-2 col-form-label font-weight-bold">Slider Image</label>
                                            <div class="col-sm-4">
                                                <input class="form-control @error('slider_images.*') is-invalid @enderror"
                                                    name="slider_images[]" type="file">
                                                @if($sliderImage)
                                                    <img src="{{ asset($sliderImage) }}" width="100" height="50"
                                                        alt="Slider Image">
                                                @endif
                                                @error('slider_images.*')
                                                    <span class="invalid-feedback">{{ $message }}</span>
                                                @enderror
                                            </div>

                                            <label class="col-sm-2 col-form-label font-weight-bold">Title</label>
                                            <div class="col-sm-3">
                                                <input class="form-control @error('titles.*') is-invalid @enderror"
                                                    name="titles[]" type="text"
                                                    value="{{ json_decode($homepage->slider_titles)[$index] }}"
                                                    placeholder="Enter a title">
                                                @error('titles.*')
                                                    <span class="invalid-feedback">{{ $message }}</span>
                                                @enderror
                                            </div>

                                            <div class="col-sm-1">
                                                <button type="button" class="btn btn-danger btn-remove-row">X</button>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>

                                <!-- Add More Slider Row Button -->
                                <div class="form-group row">
                                    <div class="col-sm-10 ml-sm-auto">
                                        <button type="button" id="add-slider-row" class="btn btn-success">+</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Session Banner Section -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="font-weight-bold">Session Banner Section</h5>
                            </div>
                            <div class="card-body">
                                <div id="banner-container">
                                    <!-- Loop through existing session banners -->
                                    @foreach(json_decode($homepage->session_banners) as $banner)
                                        <div class="form-group row banner-group">
                                            <label class="col-sm-2 col-form-label font-weight-bold">Offer Banner</label>
                                            <div class="col-sm-4">
                                                <input class="form-control @error('session_banners.*') is-invalid @enderror"
                                                    name="session_banners[]" type="file">
                                                @if($banner)
                                                    <img src="{{ asset($banner) }}" width="100" height="50"
                                                        alt="Session Banner">
                                                @endif
                                                @error('session_banners.*')
                                                    <span class="invalid-feedback">{{ $message }}</span>
                                                @enderror
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>

                        <!-- Card Title, Card Image, Card Destination Section -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="font-weight-bold">Card Section</h5>
                            </div>
                            <div class="card-body">
                                <div id="card-container">
                                    <!-- Loop through existing card data -->
                                    @foreach(json_decode($homepage->cards) as $card)
                                        <div class="form-group row card-group">
                                            <div class="col-sm-3">
                                                <label class="font-weight-bold">Card Title</label>
                                                <input class="form-control @error('card_titles.*') is-invalid @enderror"
                                                    name="card_titles[]" type="text" value="{{ $card->title }}"
                                                    placeholder="Enter card title">
                                                @error('card_titles.*')
                                                    <span class="invalid-feedback">{{ $message }}</span>
                                                @enderror
                                            </div>

                                            <div class="col-sm-3">
                                                <label class="font-weight-bold">Card Image</label>
                                                <input class="form-control @error('card_images.*') is-invalid @enderror"
                                                    name="card_images[]" type="file">
                                                @if($card->image)
                                                    <img src="{{ asset($card->image) }}" width="100" height="50"
                                                        alt="Card Image">
                                                @endif
                                                @error('card_images.*')
                                                    <span class="invalid-feedback">{{ $message }}</span>
                                                @enderror
                                            </div>

                                            <div class="col-sm-3">
                                                <label class="font-weight-bold">Card Destination</label>
                                                <input
                                                    class="form-control @error('card_destinations.*') is-invalid @enderror"
                                                    name="card_destinations[]" type="text" value="{{ $card->destination }}"
                                                    placeholder="Enter card destination">
                                                @error('card_destinations.*')
                                                    <span class="invalid-feedback">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="col-sm-3 mt-4">
                                                <button type="button" class="btn btn-danger btn-remove-card-row">X</button>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <!-- Add More Card Row Button -->
                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <button type="button" id="add-card-row" class="btn btn-success">+</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <button class="btn btn-primary" type="submit">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        // Add new slider row
        $('#add-slider-row').on('click', function () {
            const newRow = `
                <div class="form-group row slider-group">
                    <label class="col-sm-2 col-form-label font-weight-bold">Slider Image</label>
                    <div class="col-sm-4">
                        <input class="form-control" name="slider_images[]" type="file">
                    </div>

                    <label class="col-sm-2 col-form-label font-weight-bold">Title</label>
                    <div class="col-sm-3">
                        <input class="form-control" name="titles[]" type="text" placeholder="Enter a title">
                    </div>

                    <div class="col-sm-1">
                        <button type="button" class="btn btn-danger btn-remove-row">X</button>
                    </div>
                </div>`;
            $('#slider-container').append(newRow);
        });

        // Remove a slider row
        $(document).on('click', '.btn-remove-row', function () {
            $(this).closest('.slider-group').remove();
        });

        // Add new card row
        $('#add-card-row').on('click', function () {
            const newCardRow = `
                <div class="form-group row card-group">
                    <div class="col-sm-3">
                        <label class="font-weight-bold">Card Title</label>
                        <input class="form-control" name="card_titles[]" type="text" placeholder="Enter card title">
                    </div>

                    <div class="col-sm-3">
                        <label class="font-weight-bold">Card Image</label>
                        <input class="form-control" name="card_images[]" type="file">
                    </div>

                    <div class="col-sm-3">
                        <label class="font-weight-bold">Card Destination</label>
                        <input class="form-control" name="card_destinations[]" type="text" placeholder="Enter card destination">
                    </div>
                    <div class="col-sm-3 mt-4">
                        <button type="button" class="btn btn-danger btn-remove-card-row">X</button>
                    </div>
                </div>`;
            $('#card-container').append(newCardRow);
        });

        // Remove a card row
        $(document).on('click', '.btn-remove-card-row', function () {
            $(this).closest('.card-group').remove();
        });
    });
</script>
@endsection