@extends('admin.app')

@section('content')
<div class="page-heading">
    <h1 class="page-title">Homepage List</h1>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="">Homepage List</a>
        </li>
    </ol>
</div>

<div class="page-content fade-in-up">
    <div class="row">
        <div class="col-md-12">
            <div class="ibox">
                <div class="ibox-head">
                    <div class="ibox-title">All Homepages</div>
                    <div class="ibox-tools">
                        <a href="{{ route('homepages.create') }}" class="btn btn-primary btn-sm">
                            <i class="fa fa-plus"></i> Add Homepage
                        </a>
                    </div>
                </div>
                <div class="ibox-body">
                    <!-- Display Success Message -->
                    @if (session('success'))
                        <div id="success-alert" class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    <!-- Homepage Table -->
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Slider Image</th>
                                <th>Session Banner</th>
                                <th>Offer Card</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($homepages as $homepage)
                                <tr>
                                    <td>
                                        @if($homepage->slider_images && count($homepage->slider_images) > 0)
                                            @foreach ($homepage->slider_images as $slider)
                                                <div>
                                                    <img src="{{ asset($slider['image']) }}" alt="{{ $slider['title'] }}"
                                                        width="100" height="50">
                                                    <p>{{ $slider['title'] }}</p>
                                                </div>
                                            @endforeach
                                        @else
                                            No Slider Image
                                        @endif
                                    </td>
                                    <td>
                                        @if(is_array($homepage->offer_image) && count($homepage->offer_image) > 0)
                                            @foreach ($homepage->offer_image as $banner)
                                                <div>
                                                    <img src="{{ asset($banner) }}" alt="Session Banner" width="100" height="50">
                                                </div>
                                            @endforeach
                                        @else
                                            No Banner
                                        @endif
                                    </td>
                                    <td>
                                        @if($homepage->offer_card && count($homepage->offer_card) > 0)
                                            @foreach ($homepage->offer_card as $card)
                                                <div>
                                                    <img src="{{ asset($card['image']) }}" alt="{{ $card['title'] }}" width="50"
                                                        height="50">
                                                    <p>{{ $card['title'] }}</p>
                                                    <p>{{ $card['destination'] }}</p>
                                                </div>
                                            @endforeach
                                        @else
                                            No Offer Card
                                        @endif
                                    </td>
                                    <td>
                                        <!-- Edit Button -->
                                        <a href="{{ route('homepages.edit', $homepage->id) }}"
                                            class="btn btn-warning btn-sm">Edit</a>

                                        <!-- Delete Form -->
                                        <form action="{{ route('homepages.destroy', $homepage->id) }}" method="POST"
                                            style="display:inline;"
                                            onsubmit="return confirm('Are you sure you want to delete this homepage?')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4" class="text-center">No homepages found</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>

                    <!-- Pagination -->
                    <div class="d-flex justify-content-between">
                        <div id="pagination-info">
                            Showing {{ $homepages->firstItem() }} to {{ $homepages->lastItem() }} of
                            {{ $homepages->total() }} entries
                        </div>
                        {{ $homepages->links() }} <!-- Pagination links -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Auto-hide Success Message -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Check if the success alert is present
        var successAlert = document.getElementById('success-alert');
        if (successAlert) {
            // Set a timeout to remove the alert after 8 seconds
            setTimeout(function () {
                successAlert.style.display = 'none';
            }, 8000); // 8000 milliseconds = 8 seconds
        }
    });
</script>

@endsection