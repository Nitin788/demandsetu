

<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h1 class="page-title">Destination List</h1>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('destinations.index')); ?>">Destination List</a>
        </li>
    </ol>
</div>

<div class="page-content fade-in-up">
    <div class="row">
        <div class="col-md-12">
            <div class="ibox">
                <div class="ibox-head">
                    <div class="ibox-title">All Destinations</div>
                    <div class="ibox-tools">
                        <a href="<?php echo e(route('destinations.create')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Add Destination</a>
                    </div>
                </div>
                <div class="ibox-body">
                    <!-- Display Success Message -->
                    <?php if(session('success')): ?>
                        <div id="success-alert" class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <!-- Destination Table -->
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Destination Name</th>
                                <th>Country</th>
                                <th>Destination Image</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($destination->name); ?></td>
                                    <td><?php echo e($destination->country->name); ?></td>
                                    <td>
                                        <?php if($destination->image): ?>
                                            <img src="<?php echo e(asset('' . $destination->image)); ?>" alt="<?php echo e($destination->name); ?>" width="100" height="50">
                                        <?php else: ?>
                                            No Image
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(ucfirst($destination->status)); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('destinations.edit', $destination->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                        <form action="<?php echo e(route('destinations.destroy', $destination->id)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this destination?')">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center">No destinations found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <!-- Pagination -->
                    <div class="d-flex justify-content-between">
                        <div id="pagination-info">
                            Showing <?php echo e($destinations->firstItem()); ?> to <?php echo e($destinations->lastItem()); ?> of
                            <?php echo e($destinations->total()); ?> entries
                        </div>
                        <?php echo e($destinations->links()); ?> <!-- Pagination links -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Auto-hide Success Message -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var successAlert = document.getElementById('success-alert');
        if (successAlert) {
            setTimeout(function () {
                successAlert.style.display = 'none';
            }, 8000); // 8000 milliseconds = 8 seconds
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\demandsetu\resources\views/admin/destinationlist.blade.php ENDPATH**/ ?>