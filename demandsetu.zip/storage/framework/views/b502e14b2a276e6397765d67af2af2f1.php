

<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h1 class="page-title">Homepage List</h1>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="">Homepage List</a>
        </li>
    </ol>
</div>

<div class="page-content fade-in-up">
    <div class="row">
        <div class="col-md-12">
            <div class="ibox">
                <div class="ibox-head">
                    <div class="ibox-title">All Homepages</div>
                    <div class="ibox-tools">
                        <a href="<?php echo e(route('homepages.create')); ?>" class="btn btn-primary btn-sm">
                            <i class="fa fa-plus"></i> Add Homepage
                        </a>
                    </div>
                </div>
                <div class="ibox-body">
                    <!-- Display Success Message -->
                    <?php if(session('success')): ?>
                        <div id="success-alert" class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <!-- Homepage Table -->
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Slider Image</th>
                                <th>Session Banner</th>
                                <th>Offer Card</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $homepages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $homepage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <?php if($homepage->slider_images && count($homepage->slider_images) > 0): ?>
                                            <?php $__currentLoopData = $homepage->slider_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div>
                                                    <img src="<?php echo e(asset($slider['image'])); ?>" alt="<?php echo e($slider['title']); ?>"
                                                        width="100" height="50">
                                                    <p><?php echo e($slider['title']); ?></p>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            No Slider Image
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(is_array($homepage->offer_image) && count($homepage->offer_image) > 0): ?>
                                            <?php $__currentLoopData = $homepage->offer_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div>
                                                    <img src="<?php echo e(asset($banner)); ?>" alt="Session Banner" width="100" height="50">
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            No Banner
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($homepage->offer_card && count($homepage->offer_card) > 0): ?>
                                            <?php $__currentLoopData = $homepage->offer_card; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div>
                                                    <img src="<?php echo e(asset($card['image'])); ?>" alt="<?php echo e($card['title']); ?>" width="50"
                                                        height="50">
                                                    <p><?php echo e($card['title']); ?></p>
                                                    <p><?php echo e($card['destination']); ?></p>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            No Offer Card
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <!-- Edit Button -->
                                        <a href="<?php echo e(route('homepages.edit', $homepage->id)); ?>"
                                            class="btn btn-warning btn-sm">Edit</a>

                                        <!-- Delete Form -->
                                        <form action="<?php echo e(route('homepages.destroy', $homepage->id)); ?>" method="POST"
                                            style="display:inline;"
                                            onsubmit="return confirm('Are you sure you want to delete this homepage?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="text-center">No homepages found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <!-- Pagination -->
                    <div class="d-flex justify-content-between">
                        <div id="pagination-info">
                            Showing <?php echo e($homepages->firstItem()); ?> to <?php echo e($homepages->lastItem()); ?> of
                            <?php echo e($homepages->total()); ?> entries
                        </div>
                        <?php echo e($homepages->links()); ?> <!-- Pagination links -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Auto-hide Success Message -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Check if the success alert is present
        var successAlert = document.getElementById('success-alert');
        if (successAlert) {
            // Set a timeout to remove the alert after 8 seconds
            setTimeout(function () {
                successAlert.style.display = 'none';
            }, 8000); // 8000 milliseconds = 8 seconds
        }
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\demandsetu\resources\views/admin/homepagelist.blade.php ENDPATH**/ ?>