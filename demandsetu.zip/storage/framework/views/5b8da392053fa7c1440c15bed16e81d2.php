

<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h1 class="page-title">Edit Home Page</h1>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="">Edit Home Page</a>
        </li>
        <li class="breadcrumb-item" style="margin-left: 30px;">
            <a href="<?php echo e(route('homepages.index')); ?>">Home Page List</a>
        </li>
    </ol>
</div>

<div class="page-content fade-in-up">
    <div class="row">
        <div class="col-md-12">
            <div class="ibox">
                <div class="ibox-head">
                    <div class="ibox-title">Edit Home Page Form</div>
                    <div class="ibox-tools">
                        <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                        <a class="fullscreen-link"><i class="fa fa-expand"></i></a>
                    </div>
                </div>
                <div class="ibox-body">
                    <form class="form-horizontal" action="<?php echo e(route('homepages.update', $homepage->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <!-- Display All Errors (if any) -->
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <!-- Slider Section -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="font-weight-bold">Slider Section</h5>
                            </div>
                            <div class="card-body">
                                <div id="slider-container">
                                    <!-- Loop through existing slider images and titles -->
                                    <?php $__currentLoopData = json_decode($homepage->slider_images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $sliderImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group row slider-group">
                                            <label class="col-sm-2 col-form-label font-weight-bold">Slider Image</label>
                                            <div class="col-sm-4">
                                                <input class="form-control <?php $__errorArgs = ['slider_images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="slider_images[]" type="file">
                                                <?php if($sliderImage): ?>
                                                    <img src="<?php echo e(asset($sliderImage)); ?>" width="100" height="50"
                                                        alt="Slider Image">
                                                <?php endif; ?>
                                                <?php $__errorArgs = ['slider_images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <label class="col-sm-2 col-form-label font-weight-bold">Title</label>
                                            <div class="col-sm-3">
                                                <input class="form-control <?php $__errorArgs = ['titles.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="titles[]" type="text"
                                                    value="<?php echo e(json_decode($homepage->slider_titles)[$index]); ?>"
                                                    placeholder="Enter a title">
                                                <?php $__errorArgs = ['titles.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-sm-1">
                                                <button type="button" class="btn btn-danger btn-remove-row">X</button>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <!-- Add More Slider Row Button -->
                                <div class="form-group row">
                                    <div class="col-sm-10 ml-sm-auto">
                                        <button type="button" id="add-slider-row" class="btn btn-success">+</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Session Banner Section -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="font-weight-bold">Session Banner Section</h5>
                            </div>
                            <div class="card-body">
                                <div id="banner-container">
                                    <!-- Loop through existing session banners -->
                                    <?php $__currentLoopData = json_decode($homepage->session_banners); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group row banner-group">
                                            <label class="col-sm-2 col-form-label font-weight-bold">Offer Banner</label>
                                            <div class="col-sm-4">
                                                <input class="form-control <?php $__errorArgs = ['session_banners.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="session_banners[]" type="file">
                                                <?php if($banner): ?>
                                                    <img src="<?php echo e(asset($banner)); ?>" width="100" height="50"
                                                        alt="Session Banner">
                                                <?php endif; ?>
                                                <?php $__errorArgs = ['session_banners.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Card Title, Card Image, Card Destination Section -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="font-weight-bold">Card Section</h5>
                            </div>
                            <div class="card-body">
                                <div id="card-container">
                                    <!-- Loop through existing card data -->
                                    <?php $__currentLoopData = json_decode($homepage->cards); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group row card-group">
                                            <div class="col-sm-3">
                                                <label class="font-weight-bold">Card Title</label>
                                                <input class="form-control <?php $__errorArgs = ['card_titles.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="card_titles[]" type="text" value="<?php echo e($card->title); ?>"
                                                    placeholder="Enter card title">
                                                <?php $__errorArgs = ['card_titles.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-sm-3">
                                                <label class="font-weight-bold">Card Image</label>
                                                <input class="form-control <?php $__errorArgs = ['card_images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="card_images[]" type="file">
                                                <?php if($card->image): ?>
                                                    <img src="<?php echo e(asset($card->image)); ?>" width="100" height="50"
                                                        alt="Card Image">
                                                <?php endif; ?>
                                                <?php $__errorArgs = ['card_images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-sm-3">
                                                <label class="font-weight-bold">Card Destination</label>
                                                <input
                                                    class="form-control <?php $__errorArgs = ['card_destinations.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="card_destinations[]" type="text" value="<?php echo e($card->destination); ?>"
                                                    placeholder="Enter card destination">
                                                <?php $__errorArgs = ['card_destinations.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-sm-3 mt-4">
                                                <button type="button" class="btn btn-danger btn-remove-card-row">X</button>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <!-- Add More Card Row Button -->
                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <button type="button" id="add-card-row" class="btn btn-success">+</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <button class="btn btn-primary" type="submit">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        // Add new slider row
        $('#add-slider-row').on('click', function () {
            const newRow = `
                <div class="form-group row slider-group">
                    <label class="col-sm-2 col-form-label font-weight-bold">Slider Image</label>
                    <div class="col-sm-4">
                        <input class="form-control" name="slider_images[]" type="file">
                    </div>

                    <label class="col-sm-2 col-form-label font-weight-bold">Title</label>
                    <div class="col-sm-3">
                        <input class="form-control" name="titles[]" type="text" placeholder="Enter a title">
                    </div>

                    <div class="col-sm-1">
                        <button type="button" class="btn btn-danger btn-remove-row">X</button>
                    </div>
                </div>`;
            $('#slider-container').append(newRow);
        });

        // Remove a slider row
        $(document).on('click', '.btn-remove-row', function () {
            $(this).closest('.slider-group').remove();
        });

        // Add new card row
        $('#add-card-row').on('click', function () {
            const newCardRow = `
                <div class="form-group row card-group">
                    <div class="col-sm-3">
                        <label class="font-weight-bold">Card Title</label>
                        <input class="form-control" name="card_titles[]" type="text" placeholder="Enter card title">
                    </div>

                    <div class="col-sm-3">
                        <label class="font-weight-bold">Card Image</label>
                        <input class="form-control" name="card_images[]" type="file">
                    </div>

                    <div class="col-sm-3">
                        <label class="font-weight-bold">Card Destination</label>
                        <input class="form-control" name="card_destinations[]" type="text" placeholder="Enter card destination">
                    </div>
                    <div class="col-sm-3 mt-4">
                        <button type="button" class="btn btn-danger btn-remove-card-row">X</button>
                    </div>
                </div>`;
            $('#card-container').append(newCardRow);
        });

        // Remove a card row
        $(document).on('click', '.btn-remove-card-row', function () {
            $(this).closest('.card-group').remove();
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\demandsetu\resources\views/admin/edithomepage.blade.php ENDPATH**/ ?>