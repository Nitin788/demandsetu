<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Demand Setu Tours</title>
    <!-- GLOBAL MAINLY STYLES -->
    <link href="<?php echo e(asset('assets/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/vendors/themify-icons/css/themify-icons.css')); ?>" rel="stylesheet" />
    <!-- PLUGINS STYLES -->
    <link href="<?php echo e(asset('assets/vendors/jvectormap/jquery-jvectormap-2.0.3.css')); ?>" rel="stylesheet" />
    <!-- THEME STYLES -->
    <link href="<?php echo e(asset('assets/css/main.min.css')); ?>" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES -->
</head>

<body class="fixed-navbar">
    <div class="page-wrapper">
        <?php echo $__env->make('admin.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Include header -->
        <?php echo $__env->make('admin.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Include sidebar -->
        <div class="content-wrapper">
            <?php echo $__env->yieldContent('content'); ?> <!-- Dynamic content -->
            <?php echo $__env->make('admin.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Include footer -->
        </div>
    </div>

    <!-- GLOBAL MAINLY SCRIPTS -->
    <script src="<?php echo e(asset('assets/vendors/jquery/dist/jquery.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/vendors/popper.js/dist/umd/popper.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/vendors/metisMenu/dist/metisMenu.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/vendors/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"
        type="text/javascript"></script>
    <!-- PAGE LEVEL PLUGINS -->
    <script src="<?php echo e(asset('assets/vendors/chart.js/dist/Chart.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/vendors/jvectormap/jquery-jvectormap-2.0.3.min.js')); ?>"
        type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/vendors/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>"
        type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/vendors/jvectormap/jquery-jvectormap-us-aea-en.js')); ?>"
        type="text/javascript"></script>
    <!-- CORE SCRIPTS -->
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>" type="text/javascript"></script>
    <!-- PAGE LEVEL SCRIPTS -->
    <script src="<?php echo e(asset('assets/js/scripts/dashboard_1_demo.js')); ?>" type="text/javascript"></script>
</body>

</html><?php /**PATH D:\xampp\htdocs\demandsetu\resources\views/admin/app.blade.php ENDPATH**/ ?>