

<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h1 class="page-title">Country List</h1>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="">Country List</a>
        </li>
    </ol>
</div>

<div class="page-content fade-in-up">
    <div class="row">
        <div class="col-md-12">
            <div class="ibox">
                <div class="ibox-head">
                    <div class="ibox-title">All Countries</div>
                    <div class="ibox-tools">
                        <a href="<?php echo e(route('countries.create')); ?>" class="btn btn-primary btn-sm"><i
                                class="fa fa-plus"></i> Add Country</a>
                    </div>
                </div>
                <div class="ibox-body">
                    <!-- Display Success Message -->
                    <?php if(session('success')): ?>
                        <div id="success-alert" class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <!-- Country Table -->
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <!-- <th>#</th> -->
                                <th>Country Name</th>
                                <th>Country Image</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <!-- <td><?php echo e($loop->iteration); ?></td> -->
                                    <td><?php echo e($country->name); ?></td>
                                    <td>
                                        <?php if($country->image): ?>
                                            <img src="<?php echo e(asset( $country->image)); ?>" alt="<?php echo e($country->name); ?>"
                                                width="100" height="50">
                                        <?php else: ?>
                                            No Image
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(ucfirst($country->status)); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('countries.edit', $country->id)); ?>"
                                            class="btn btn-warning btn-sm">Edit</a>
                                        <form action="<?php echo e(route('countries.destroy', $country->id)); ?>" method="POST"
                                            style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm"
                                                onclick="return confirm('Are you sure you want to delete this country?')">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center">No countries found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <!-- Pagination -->
                    <div class="d-flex justify-content-between">
                        <div id="pagination-info">
                            Showing <?php echo e($countries->firstItem()); ?> to <?php echo e($countries->lastItem()); ?> of
                            <?php echo e($countries->total()); ?> entries
                        </div>
                        <?php echo e($countries->links()); ?> <!-- Pagination links -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Auto-hide Success Message -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Check if the success alert is present
        var successAlert = document.getElementById('success-alert');
        if (successAlert) {
            // Set a timeout to remove the alert after 8 seconds
            setTimeout(function () {
                successAlert.style.display = 'none';
            }, 8000); // 8000 milliseconds = 8 seconds
        }
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\demandsetu\resources\views\admin\countrylist.blade.php ENDPATH**/ ?>