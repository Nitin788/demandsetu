<nav class="page-sidebar" id="sidebar">
    <div id="sidebar-collapse">
        <div class="admin-block d-flex">
            <div>
                <img src="<?php echo e(asset('./assets/img/admin-avatar.png')); ?>" width="45px">
            </div>
            <div class="admin-info">
                <div class="font-strong">
                    <?php echo e(Auth::user()->name); ?>

                </div><small> <?php echo e(Auth::user()->email); ?></small>
            </div>
        </div>
        <ul class="side-menu metismenu">
            <li>
                <a class="active" href="<?php echo e(route('dashboard')); ?>"><i class="sidebar-item-icon fa fa-th-large"></i>
                    <span class="nav-label">Dashboard</span>
                </a>
            </li>
            <li class="heading">Homre Page</li>
            <li>
                <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                    <span class="nav-label">Home Page</span><i class="fa fa-angle-left arrow"></i></a>
                <ul class="nav-2-level collapse" aria-expanded="false">
                    <li>
                        <a href="<?php echo e(route('homepages.create')); ?>">Add Home Page Data</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('homepages.index')); ?>">Home Page List</a>
                    </li>
                    <!-- <li>
                        <a href="#">Panels</a>
                    </li>
                    <li>
                        <a href="#">Buttons</a>
                    </li>
                    <li>
                        <a href="#">Tabs</a>
                    </li>
                    <li>
                        <a href="#">Alerts & Tooltips</a>
                    </li>
                    <li>
                        <a href="#">Badges & Progress</a>
                    </li>
                    <li>
                        <a href="#">List</a>
                    </li>
                    <li>
                        <a href="#">Card</a>
                    </li> -->
                </ul>
            </li>
            <li class="heading">Country And Places</li>
            <li>
                <a href="javascript:;"><i class="sidebar-item-icon fa fa-edit"></i>
                    <span class="nav-label">Country&Destinations</span><i class="fa fa-angle-left arrow"></i></a>
                <ul class="nav-2-level collapse" aria-expanded="false">
                    <li>
                        <a href="<?php echo e(route('countries.create')); ?>">Add Country</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('countries.index')); ?>">Country List</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('destinations.create')); ?>">Add Destination</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('destinations.index')); ?>">Destination List</a>
                    </li>
                    <!-- <li>
                        <a href="#">Text Editors</a>
                    </li> -->
                </ul>
            </li>
            <li class="heading">Places</li>
            <li>
                <a href="javascript:;"><i class="sidebar-item-icon fa fa-table"></i>
                    <span class="nav-label">Places</span><i class="fa fa-angle-left arrow"></i></a>
                <ul class="nav-2-level collapse" aria-expanded="false">
                    <li>
                        <a href="<?php echo e(route('places.create')); ?>">Add Place</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('places.index')); ?>">Place List</a>
                    </li>
                </ul>
            </li>
            <!-- <li>
                <a href="javascript:;"><i class="sidebar-item-icon fa fa-bar-chart"></i>
                    <span class="nav-label">Charts</span><i class="fa fa-angle-left arrow"></i></a>
                <ul class="nav-2-level collapse" aria-expanded="false">
                    <li>
                        <a href="#">Flot Charts</a>
                    </li>
                    <li>
                        <a href="#">Morris Charts</a>
                    </li>
                    <li>
                        <a href="#">Chart.js</a>
                    </li>
                    <li>
                        <a href="#">Sparkline Charts</a>
                    </li>
                </ul>
            </li> -->
            <!-- <li>
                <a href="javascript:;"><i class="sidebar-item-icon fa fa-map"></i>
                    <span class="nav-label">Maps</span><i class="fa fa-angle-left arrow"></i></a>
                <ul class="nav-2-level collapse" aria-expanded="false">
                    <li>
                        <a href="#">Vector maps</a>
                    </li>
                </ul>
            </li> -->
            <!-- <li>
                <a href="#"><i class="sidebar-item-icon fa fa-smile-o"></i>
                    <span class="nav-label">Icons</span>
                </a>
            </li> -->
            <!-- <li class="heading">PAGES</li> -->
            <!-- <li>
                <a href="javascript:;"><i class="sidebar-item-icon fa fa-envelope"></i>
                    <span class="nav-label">Mailbox</span><i class="fa fa-angle-left arrow"></i></a>
                <ul class="nav-2-level collapse" aria-expanded="false">
                    <li>
                        <a href="#">Inbox</a>
                    </li>
                    <li>
                        <a href="#">Mail view</a>
                    </li>
                    <li>
                        <a href="#">Compose mail</a>
                    </li>
                </ul>
            </li> -->
            <!-- <li>
                <a href="#"><i class="sidebar-item-icon fa fa-calendar"></i>
                    <span class="nav-label">Calendar</span>
                </a>
            </li> -->
            <!-- <li>
                <a href="javascript:;"><i class="sidebar-item-icon fa fa-file-text"></i>
                    <span class="nav-label">Pages</span><i class="fa fa-angle-left arrow"></i></a>
                <ul class="nav-2-level collapse" aria-expanded="false">
                    <li>
                        <a href="#">Invoice</a>
                    </li>
                    <li>
                        <a href="#">Profile</a>
                    </li>
                    <li>
                        <a href="#">Login</a>
                    </li>
                    <li>
                        <a href="#">Register</a>
                    </li>
                    <li>
                        <a href="#">Lockscreen</a>
                    </li>
                    <li>
                        <a href="#">Forgot password</a>
                    </li>
                    <li>
                        <a href="#">404 error</a>
                    </li>
                    <li>
                        <a href="#">500 error</a>
                    </li>
                </ul>
            </li> -->
            <!-- <li>
                <a href="javascript:;"><i class="sidebar-item-icon fa fa-sitemap"></i>
                    <span class="nav-label">Menu Levels</span><i class="fa fa-angle-left arrow"></i></a>
                <ul class="nav-2-level collapse" aria-expanded="false">
                    <li>
                        <a href="javascript:;">Level 2</a>
                    </li>
                    <li>
                        <a href="javascript:;">
                            <span class="nav-label">Level 2</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-3-level collapse" aria-expanded="false">
                            <li>
                                <a href="javascript:;">Level 3</a>
                            </li>
                            <li>
                                <a href="javascript:;">Level 3</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li> -->
        </ul>
    </div>
</nav><?php /**PATH D:\xampp\htdocs\demandsetu\resources\views/admin/inc/sidebar.blade.php ENDPATH**/ ?>