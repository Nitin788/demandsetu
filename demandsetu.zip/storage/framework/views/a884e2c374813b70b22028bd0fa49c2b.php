

<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h1 class="page-title">Places List</h1>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('places.index')); ?>">Places List</a>
        </li>
    </ol>
</div>

<div class="page-content fade-in-up">
    <div class="row">
        <div class="col-md-12">
            <div class="ibox">
                <div class="ibox-head">
                    <div class="ibox-title">All Places</div>
                    <div class="ibox-tools">
                        <a href="<?php echo e(route('places.create')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i>
                            Add Place</a>
                    </div>
                </div>
                <div class="ibox-body">
                    <!-- Display Success Message -->
                    <?php if(session('success')): ?>
                        <div id="success-alert" class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <!-- Places Table -->
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Destination</th>
                                <th>Offers</th>
                                <th>Price</th>
                                <th>Sale Price</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($place->title); ?></td>
                                    <td><?php echo e($place->destination->name ?? 'N/A'); ?></td>
                                    <!-- Display associated destination name -->
                                    <td><?php echo e($place->offers); ?></td>
                                    <td><?php echo e($place->price); ?></td>
                                    <td><?php echo e($place->sale_price); ?></td>
                                    <td><?php echo e(ucfirst($place->status)); ?></td> <!-- Capitalize first letter of status -->
                                    <td>
                                        <a href="<?php echo e(route('places.edit', $place->id)); ?>"
                                            class="btn btn-warning btn-sm">Edit</a>
                                        <form action="<?php echo e(route('places.destroy', $place->id)); ?>" method="POST"
                                            style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm"
                                                onclick="return confirm('Are you sure you want to delete this place?')">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center">No places found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <!-- Pagination -->
                    <div class="d-flex justify-content-between">
                        <div id="pagination-info">
                            Showing <?php echo e($places->firstItem()); ?> to <?php echo e($places->lastItem()); ?> of <?php echo e($places->total()); ?>

                            entries
                        </div>
                        <?php echo e($places->links()); ?> <!-- Pagination links -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Auto-hide Success Message -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Check if the success alert is present
        var successAlert = document.getElementById('success-alert');
        if (successAlert) {
            // Set a timeout to remove the alert after 8 seconds
            setTimeout(function () {
                successAlert.style.display = 'none';
            }, 8000); // 8000 milliseconds = 8 seconds
        }
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\demandsetu\resources\views/admin/placelist.blade.php ENDPATH**/ ?>