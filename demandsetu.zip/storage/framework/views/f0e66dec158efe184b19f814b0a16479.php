<footer class="page-footer">
    <div class="font-13">
        © <?php echo e(date('Y')); ?> <b>Pluto Tours</b> - All rights reserved.
    </div>
    <div class="font-13">
        Developed by <b>Nitin Jamwal</b>
    </div>
    <div class="to-top" style="display: block;">
        <i class="fa fa-angle-double-up"></i>
    </div>
</footer>
<?php /**PATH D:\xampp\htdocs\demandsetu\resources\views\admin\inc\footer.blade.php ENDPATH**/ ?>