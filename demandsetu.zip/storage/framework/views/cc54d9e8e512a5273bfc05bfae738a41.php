
<?php $__env->startSection('content'); ?>
<div class="page-content fade-in-up">
    <div class="row">
        <div class="col-lg-3 col-md-6">
            <div class="ibox bg-success color-white widget-stat">
                <div class="ibox-body">
                    <h2 class="m-b-5 font-strong"><?php echo e($destinationCount); ?></h2>
                    <div class="m-b-5">TOTAL DESTINATIONS</div><a href="<?php echo e(route('destinations.index')); ?>"><i
                            class="ti-location-pin widget-stat-icon"></i></a>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="ibox bg-info color-white widget-stat">
                <div class="ibox-body">
                    <h2 class="m-b-5 font-strong"><?php echo e($totalPlaces); ?></h2>
                    <div class="m-b-5">TOTAL PLACES</div>
                    <a href="<?php echo e(route('places.index')); ?>"><i
                            class="ti-location-pin widget-stat-icon"></i></a><!-- Change icon if needed -->
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="ibox bg-warning color-white widget-stat">
                <div class="ibox-body">
                    <h2 class="m-b-5 font-strong">$1570</h2>
                    <div class="m-b-5">TOTAL INCOME</div><i class="fa fa-money widget-stat-icon"></i>
                </div>
            </div>
        </div>
        <!-- <div class="col-lg-3 col-md-6">
            <div class="ibox bg-danger color-white widget-stat">
                <div class="ibox-body">
                    <h2 class="m-b-5 font-strong">108</h2>
                    <div class="m-b-5">NEW USERS</div><i class="ti-user widget-stat-icon"></i>
                    <div><i class="fa fa-level-down m-r-5"></i><small>-12% Lower</small></div>
                </div>
            </div>
        </div> -->
    </div>
    <div class="page-content fade-in-up">
        <div class="row">
            <div class="col-md-12">
                <div class="ibox">
                    <div class="ibox-head">
                        <div class="ibox-title">All Places</div>
                        <div class="ibox-tools">
                            <a href="<?php echo e(route('places.create')); ?>" class="btn btn-primary btn-sm"><i
                                    class="fa fa-plus"></i>
                                Add Place</a>
                        </div>
                    </div>
                    <div class="ibox-body">
                        <!-- Display Success Message -->
                        <?php if(session('success')): ?>
                            <div id="success-alert" class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <!-- Places Table -->
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Destination</th>
                                    <th>Offers</th>
                                    <th>Price</th>
                                    <th>Sale Price</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($place->title); ?></td>
                                        <td><?php echo e($place->destination->name ?? 'N/A'); ?></td>
                                        <!-- Display associated destination name -->
                                        <td><?php echo e($place->offers); ?></td>
                                        <td><?php echo e($place->price); ?></td>
                                        <td><?php echo e($place->sale_price); ?></td>
                                        <td><?php echo e(ucfirst($place->status)); ?></td> <!-- Capitalize first letter of status -->
                                        <td>
                                            <a href="<?php echo e(route('places.edit', $place->id)); ?>"
                                                class="btn btn-warning btn-sm">Edit</a>
                                            <form action="<?php echo e(route('places.destroy', $place->id)); ?>" method="POST"
                                                style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm"
                                                    onclick="return confirm('Are you sure you want to delete this place?')">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No places found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\demandsetu\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>