

<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <h1 class="page-title">Edit Country Form</h1>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('countries.index')); ?>">Country List</a>
        </li>
        <li class="breadcrumb-item" style="margin-left: 30px;">
            <a href="<?php echo e(route('countries.edit', $countries->id)); ?>">Edit Country</a>
        </li>
    </ol>
</div>
<div class="page-content fade-in-up">
    <div class="row">
        <div class="col-md-12">
            <div class="ibox">
                <div class="ibox-head">
                    <div class="ibox-title">Edit Country Form</div>
                    <div class="ibox-tools">
                        <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                        <a class="fullscreen-link"><i class="fa fa-expand"></i></a>
                    </div>
                </div>
                <div class="ibox-body">
                    <!-- Use PUT method to update the country -->
                    <form class="form-horizontal" action="<?php echo e(route('countries.update', $countries->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?> <!-- To use the PUT HTTP method for updating -->

                        <!-- Display all errors at the top of the form -->
                        <?php if($errors->any()): ?>
                            <div id="error-alert" class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <!-- Country Name and Country Image in Same Row (col-md-6) -->
                        <div class="form-group row">
                            <!-- Country Name -->
                            <div class="col-sm-6">
                                <label class="col-form-label font-weight-bold">Country Name</label>
                                <input class="form-control <?php $__errorArgs = ['country_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="country_name" type="text" placeholder="Enter country name" required
                                    value="<?php echo e(old('country_name', $countries->name)); ?>">
                                <?php $__errorArgs = ['country_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Country Image -->
                            <div class="col-sm-6">
                                <label class="col-form-label font-weight-bold">Country Image</label>
                                <input class="form-control <?php $__errorArgs = ['country_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="country_image" type="file">
                                <?php $__errorArgs = ['country_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Display the current image if exists -->
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <?php if($countries->image): ?>
                                    <label class="col-form-label font-weight-bold">Current Image</label><br>
                                    <img src="<?php echo e(asset('' . $countries->image)); ?>" width="100" alt="<?php echo e($countries->name); ?>">
                                <?php else: ?>
                                    <label class="col-form-label font-weight-bold">Current Image</label><br>
                                    <p>No image available</p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Country Status -->
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <label class="col-form-label font-weight-bold">Status</label>
                                <select class="form-control <?php $__errorArgs = ['country_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="country_status" required>
                                    <option value="active" <?php echo e(old('country_status', $countries->status) == 'active' ? 'selected' : ''); ?>>Active</option>
                                    <option value="inactive" <?php echo e(old('country_status', $countries->status) == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                                </select>
                                <?php $__errorArgs = ['country_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="form-group row">
                            <div class="col-sm-10 ml-sm-auto">
                                <button class="btn btn-info" type="submit">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript to hide error messages after 8 seconds -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Check if there's an error alert displayed
        const errorAlert = document.getElementById('error-alert');
        if (errorAlert) {
            // Set a timeout to remove the error alert after 8 seconds (8000 ms)
            setTimeout(function () {
                errorAlert.style.display = 'none'; // Hide the error alert
            }, 8000);
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\demandsetu\resources\views\admin\editcountry.blade.php ENDPATH**/ ?>